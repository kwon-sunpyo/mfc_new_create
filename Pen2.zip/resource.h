﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++에서 생성한 포함 파일입니다.
// Pen2.rc에서 사용되고 있습니다.
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_Pen2TYPE                    130
#define ID_SEL_COL                      32771
#define ID_SEL_SIZE                     32772
#define ID_SIZE_1                       32773
#define ID_SIZE_10                      32774
#define ID_SIZE_15                      32775
#define ID_SEL_SIZE32776                32776
#define ID_SIZE_11                      32777
#define ID_SIZE_20                      32778
#define ID_SIZE_50                      32779

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        310
#define _APS_NEXT_COMMAND_VALUE         32780
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
